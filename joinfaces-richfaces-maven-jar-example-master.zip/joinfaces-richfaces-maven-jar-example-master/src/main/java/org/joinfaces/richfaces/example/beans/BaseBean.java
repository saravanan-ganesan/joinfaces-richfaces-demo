package org.joinfaces.richfaces.example.beans;

public class BaseBean {

	
}
