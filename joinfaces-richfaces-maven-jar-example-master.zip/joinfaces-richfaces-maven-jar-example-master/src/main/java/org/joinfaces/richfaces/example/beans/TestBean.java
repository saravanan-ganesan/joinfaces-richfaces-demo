package org.joinfaces.richfaces.example.beans;

import javax.inject.Named;

import lombok.Getter;
import lombok.Setter;

@Named
@Getter
@Setter
public class TestBean  {

	public String page1() {
		System.out.println("inside page1 after clicking on Test button");
		return "/page1.xhtml?faces-redirect=true";
	}
	
	public String page2() {
		System.out.println("inside page2 after clicking on Home button");
		return "/page2.xhtml?faces-redirect=true";
	}
	
	public String home() {
		return "/start.xhtml?faces-redirect=true";
	}
}
