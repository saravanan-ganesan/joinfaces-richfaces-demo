package org.joinfaces.richfaces.example.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Aspect
@Component
@EnableAspectJAutoProxy
public class LoggerConfig {
	
	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	private final String PACKAGE_PATH = "execution(* org.joinfaces.richfaces.example..*.*(..)))";
	
	@Pointcut(PACKAGE_PATH)
	public void appPointcut() {
		// Method is empty as this is just a point-cut, the implementations are in the advice.
	}

	@AfterThrowing(pointcut = "appPointcut()", throwing = "e")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {
		
		LOGGER.error("Exception in {}.{}() with cause = {}", joinPoint.getSignature().getDeclaringTypeName(),
				joinPoint.getSignature().getName(), e.getCause() != null ? e.getCause() : "NULL");
		e.printStackTrace();
	}

	@Around("appPointcut()")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {

		Object result;

		LOGGER.info("Enter: {}.{}()", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());

		try {
			result = joinPoint.proceed();

		} finally {
			LOGGER.info("Exit: {}.{}()", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
		}
		
		return result;
	}
	
}
